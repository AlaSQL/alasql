./ds2_create_cust     1  1M US   M 0 > us_cust.csv &
./ds2_create_cust  1M+1  2M ROW  M 0 > row_cust.csv &
