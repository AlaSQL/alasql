./ds2_create_cust       1  100M US  L 0 > us_cust.csv &
./ds2_create_cust  100M+1  200M ROW L 0 > row_cust.csv &
