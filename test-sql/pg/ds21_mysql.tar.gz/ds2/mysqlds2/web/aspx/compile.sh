mcs /t:library /out:bin/ds2.dll -r:System.Web -r:System.Data -r:System.Drawing -r:MySql.Data AssemblyInfo.cs dslogin.aspx.cs dsnewcustomer.aspx.cs dsbrowse.aspx.cs dspurchase.aspx.cs dscommon.cs
