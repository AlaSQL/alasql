# test.sql

SELECT NOW();
SELECT COUNT(*) FROM limbs;
