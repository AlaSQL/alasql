The flags directory contains some sample image files that you can load
into the database with load_image.pl.  The flag images come from the
CIA World Factbook, available at:

http://www.odci.gov/cia/publications/factbook/

Mime types for GIF and JPEG files are:

*.gif files: image/gif
*.jpg files: image/jpeg
