LOAD DATA LOCAL INFILE "grade_event.txt" INTO TABLE grade_event;
