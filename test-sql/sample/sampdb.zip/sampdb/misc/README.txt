create_federated_student.sql
  Create a FEDERATED table, naming the connection parameters in the
  CONNECTION option.
create_federated_student2.sql
  Create a FEDERATED table, using a server definition and naming the server
  in the CONNECTION option.
interests.sh
interests.bat
  UNIX shell script and Windows batch script for running USHL
  interest-keyword searches.
missing_scores.sql
  Find students who haven't taken a test or quiz.
mkinsert
  Generate INSERT statements from tab-delimited data, suitable for feeding
  to mysql.  Useful if you have a file of data but an old version of MySQL
  that doesn't support LOAD DATA LOCAL or mysqlimport --local.
