<?php print ("hello, world\n"); ?>
