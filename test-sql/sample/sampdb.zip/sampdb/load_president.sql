LOAD DATA LOCAL INFILE "president.txt" INTO TABLE president;
