/*****************************************
 U.P. Attraction Tables
*****************************************/
use master;
drop database UPAttractions;
go

create database UPAttractions;
go

use UPAttractions;

CREATE TABLE county (
   county_id DECIMAL,
   county_name VARCHAR(15),
   state CHAR(2),
   CONSTRAINT county_pkey
      PRIMARY KEY (county_id));

CREATE TABLE new_counties (
   county_id DECIMAL,
   county_name VARCHAR(15),
   state CHAR(2));

CREATE TABLE city (
   city_id DECIMAL,
   city_name VARCHAR(16),
   county_id DECIMAL,
   CONSTRAINT city_pkey
      PRIMARY KEY (city_id),
   CONSTRAINT city_in_county
      FOREIGN KEY (county_id)
      REFERENCES county);

CREATE TABLE attraction (
   attraction_id DECIMAL,
   attraction_name VARCHAR(35),
   attraction_url VARCHAR(40),
   government_owned CHAR(1),
   city_id DECIMAL,
   CONSTRAINT attraction_pkey
      PRIMARY KEY (attraction_id),
   CONSTRAINT attraction_in_city
      FOREIGN KEY (city_id)
      REFERENCES city,
   CONSTRAINT government_owned_yn
      CHECK (government_owned IN ('Y','N')));

CREATE TABLE alger_attractions (
   attraction_id DECIMAL,
   attraction_name VARCHAR(35),
   attraction_url VARCHAR(40),
   government_owned CHAR(1),
   city_id DECIMAL);

CREATE TABLE marquette_attractions (
   attraction_id DECIMAL,
   attraction_name VARCHAR(35),
   attraction_url VARCHAR(40),
   government_owned CHAR(1),
   city_id DECIMAL);

CREATE TABLE other_attractions (
   attraction_id DECIMAL,
   attraction_name VARCHAR(35),
   attraction_url VARCHAR(40),
   government_owned CHAR(1),
   city_id DECIMAL);

CREATE TABLE attraction_urls (
   id DECIMAL,
   url VARCHAR(40));

CREATE TABLE attraction_names (
   id DECIMAL,
   name VARCHAR(35));

GO

CREATE VIEW city_attractions
(city_name, attraction_name)
AS SELECT c.city_name, a.attraction_name
FROM city c INNER JOIN attraction a
     ON c.city_id = a.city_id

GO

INSERT INTO county VALUES (1,'Alger','MI');
INSERT INTO county VALUES (2,'Marquette','MI');
INSERT INTO county VALUES (3,'Chippewa','MI');
INSERT INTO county VALUES (4,'Mackinac','MI');
INSERT INTO county VALUES (5, 'Delta','MI');
INSERT INTO county VALUES (6, 'Luce','MI');
INSERT INTO county VALUES (7, 'Schoolcraft','MI');
INSERT INTO county VALUES (8, 'Menominee','MI');
INSERT INTO county VALUES (9, 'Dickenson','MI');
INSERT INTO county VALUES (10, 'Baraga','MI');
INSERT INTO county VALUES (11, 'Houghton','MI');
INSERT INTO county VALUES (12, 'Keweenaw','MI');
INSERT INTO county VALUES (13, 'Ontonagon','MI');
INSERT INTO county VALUES (14, 'Gogebic','MI');
INSERT INTO county VALUES (15, 'Iron','MI');
INSERT INTO county VALUES (16, 'Wane','MI');
INSERT INTO county VALUES (18, 'McComb','MI');

INSERT INTO new_counties VALUES (1,'Alger','MI');
INSERT INTO new_counties VALUES (2,'Marquette','MI');
INSERT INTO new_counties VALUES (3,'Chippewa','MI');
INSERT INTO new_counties VALUES (16,'Wayne','MI');
INSERT INTO new_counties VALUES (17,'Oakland','MI');
INSERT INTO new_counties VALUES (18,'Macomb','MI');

INSERT INTO city VALUES (1,'Munising',1);
INSERT INTO city VALUES (2,'St. Ignace',4);
INSERT INTO city VALUES (3,'Marquette',2);
INSERT INTO city VALUES (4,'Iron River',15);
INSERT INTO city VALUES (5,'Bessemer',14);
INSERT INTO city VALUES (6,'Silver City',13);
INSERT INTO city VALUES (7,'Copper Harbor',12);
INSERT INTO city VALUES (8,'Hancock',11);
INSERT INTO city VALUES (9,'L''Anse',10);
INSERT INTO city VALUES (10,'Vulcan',9);
INSERT INTO city VALUES (11,'Carbondale',8);
INSERT INTO city VALUES (12,'Germfask',7);
INSERT INTO city VALUES (13,'Newberry',6);
INSERT INTO city VALUES (14,'Gladstone',5);
INSERT INTO city VALUES (15,'Sault Ste. Marie',3);
INSERT INTO city VALUES (16,'Ishpeming',2);
INSERT INTO city VALUES (17,NULL,1);
INSERT INTO city VALUES (18,'Brimley',3);


/* Alger County */
INSERT INTO attraction VALUES (1, 'Pictured Rocks',
                               'www.nps.gov/piro/',
                               'Y', 1);
INSERT INTO attraction VALUES (2, 'Valley Spur',
                               'www.valleyspur.com',
                               'Y', 1);
INSERT INTO attraction VALUES (3, 'Shipwreck Tours',
                               'www.shipwrecktours.com',
                               'N', 1);

INSERT INTO attraction VALUES (23, 'Grand Sable Dunes',
                               NULL, NULL, NULL);

/* Marquette County */
INSERT INTO attraction VALUES (4, 'Ski Hall of Fame',
                               'www.skihall.com',
                               'N', 16);
INSERT INTO attraction VALUES (5, 'Da Yoopers Tourist Trap',
                               'www.dayoopers.com',
                               'N', 16);
INSERT INTO attraction VALUES (6, 'Marquette County Historical Museum',
                               'www.marquettecohistory.org',
                               'N', 3);
INSERT INTO attraction VALUES (7, 'Upper Peninsula Children''s Museum',
                               'www.upcmkids.org',
                               'N', 3);
INSERT INTO attraction VALUES (8, 'Marquette Maritime Museum',
                               'mqtmaritimemuseum.com',
                               'N', 3);

/* Chippewa County */
INSERT INTO attraction VALUES (9, 'Valley Camp',
                               'www.thevalleycamp.com',
                               'N', 15);

/* Mackinac County */
INSERT INTO attraction VALUES (10, 'Mackinac Bridge',
                               'www.mackinacbridge.org',
                               'Y', 2);

/* Delta County */
INSERT INTO attraction VALUES (11, 'Hoegh Pet Casket Company',
                               'hoegh.abka.com',
                               'N', 14);

/* Luce County */
/* Nothing for Luce County. This is on purpose, because
   I need one county with no attractions to demonstrate
   certain GROUP BY behavior. */

/* Schoolcraft County */
INSERT INTO attraction VALUES (12, 'Seney National Wildlife Refuge',
                               'midwest.fws.gov/seney/',
                               'Y', 12);

/* Menominee */
INSERT INTO attraction VALUES (13, 'Wells State Park',
                               NULL,'Y',NULL);

/* Dickenson */
/* Nothing for Dickenson either. */

/* Baraga */
INSERT INTO attraction VALUES (14, 'Bishop Baraga Shrine',
                               'www.baragashrine.com',
                               'N', 9);

INSERT INTO attraction VALUES (15, 'Mount Arvon',
                               NULL,NULL,NULL);

/* Houghton */
INSERT INTO attraction VALUES (16,'Quincy Steam Hoist',
                               'www.quincymine.com',
                               'N',8);
INSERT INTO attraction VALUES (17,'Temple Jacob',
                               'www.uahc.org/mi/mi010',
                               'N',8);
INSERT INTO attraction VALUES (18,'Finlandia University',
                               'www.finlandia.edu',
                               'N',8);

/* Keweenaw */
INSERT INTO attraction VALUES (19,'Fort Wilkins State Park',
                               NULL,'Y',7);

/* Ontonagon */
INSERT INTO attraction VALUES (20,'Porcupine Mountain Wilderness',
                               NULL,'Y',6);

/* Gogebic */
INSERT INTO attraction VALUES (21,'Copper Peak Ski Flying Hill',
                               'www.westernup.com/copperpeak/',
                               'N',5);

/* Iron */
INSERT INTO attraction VALUES (22,'Iron County Historical Museum',
                               'www.ironcountymuseum.com',
                               'N',4);
print 'build complete';