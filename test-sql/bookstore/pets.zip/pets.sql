/*
Script to demonstrate data warehoue rollup and cube queries. Uses a non-normalized pet store database. This initial version does not usetables for the dimensions to create a truse star schema.

Dan D'Urso		scripts1@dhdursoassociates.com
*/

use master;
drop database petsdw;
go

create database petsdw;
go

use Petsdw;

-- create the fact table
CREATE TABLE PetFacts
(	
	Type			CHAR(15),
	Store			CHAR(15),
	Number		INT
);
--load pets fact table
INSERT INTO PetFacts VALUES('Dog', 'Miami', 12);
INSERT INTO PetFacts VALUES('Cat', 'Miami', 18);
INSERT INTO PetFacts VALUES('Turtle', 'Tampa', 4);
INSERT INTO PetFacts VALUES('Dog', 'Tampa', 14);
INSERT INTO PetFacts VALUES('Cat', 'Naples', 9);
INSERT INTO PetFacts VALUES('Dog', 'Naples', 5);
INSERT INTO PetFacts VALUES('Turtle', 'Naples', 1);

--show table entries
SELECT * FROM PetFacts
ORDER BY type,store;

--calculate aggregates with rollup to pet type
SELECT Type, Store, SUM(Number) as Number
FROM PetFacts
GROUP BY type, store WITH ROLLUP;

--calculate aggregates with cube
--rolls up to store
--adds cross totals by pet type
SELECT Type, Store, SUM(Number) as Number
FROM PetFacts
GROUP BY type, store WITH CUBE;

